Welcome to Mine Wars - A Star Wars Texture Pack.

The rules of usage are as follows:

1. This pack's material can be used in another pack HOWEVER you must ask me personally and I must approve, 
you must give proper credit AND it must differentiate SUBSTANTIALLY from this pack.

2. If I approve any non-personal usage of this pack by you, please CONSULT ME FIRST as some of the things in here 
are not my work and I will need to tell you who to credit for what parts.

3. If you do completely follow the above two rules should you decide to use this pack, you must also not make ANY
personal and/or monetary gain from this pack in ANY way.

4. If the above 3 rules are followed, you MUST have fun. :) 