
Ovo's Rustic Pack  [http://www.planetminecraft.com/texture_pack/ovos-rustic-pack/]

This pack contains many texture done by the community specifically for this texture pack. You are not allowed to redistribute any of these in a remix pack or such without permission from their respective author.
Authors of all textures can be found on the customizer (http://minecraftcustomizer.net/pack/Ovo+-+Rustic+-+Redemption)

The custom water and lava animations are the creation of JohnSmith.
The font is a common effort mostly credited to its unknown original creator and to Misa.

Ovocean <contact@ovocean.com>
