Thanks for trying WolfCraft!
http://www.minecraftforum.net/topic/308925-/

I will be updating a lot, so stay tuned!
The pack isn't finished yet, so if you like my textures, bookmark the thread for updates.


How to add this texture pack:
- Drag this entire .zip file into your '.minecraft\texturepacks' folder
- Use the latest HD patcher to patch minecraft
- Load Minecraft and select the texture pack
- Play!


Have fun!
~TheMadWolf.